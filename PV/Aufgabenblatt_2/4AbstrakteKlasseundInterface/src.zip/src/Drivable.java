public interface Drivable {

    public void driveForward(double distance);

}
