/**
 * A general drink, served at room temperature.
 */
public class Drink {

    public String temperature = "room temperature";

    public String getTemperature() {
        return temperature;
    }
}