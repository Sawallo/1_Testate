public class Bindung2 {
    
}
