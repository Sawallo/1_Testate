package src.gleich;
//import src.gleich.Methoden;

public class Zugriff {


    
    public static void main(String[] args){

        Methoden tier = new Methoden();
        System.out.println(tier.hund());
        System.out.println(tier.katze());
    }
}
