public abstract class MobileRobot {
    
    public int x = 1;
    public int y = 1;
    public int z = 1;

    public abstract void bringup();

}
