package src.anders;
import src.gleich.Methoden;

public class Zugriff2 {


    
    public static void main(String[] args){

        Methoden tier = new Methoden();
        System.out.println(tier.hund());
        //System.out.println(tier.katze());
    }
}
