/**
 * Class A.
 */
public class A{ 
	public String getName(){
		return "Klasse A";
	}
}