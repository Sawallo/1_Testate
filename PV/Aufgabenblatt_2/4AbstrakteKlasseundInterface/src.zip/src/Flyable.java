public interface Flyable {
    
    public void flyForward(double distance);

}
