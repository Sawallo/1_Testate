/**
 * Class B.
 */
public class B{ }