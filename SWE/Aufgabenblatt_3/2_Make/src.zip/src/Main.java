/**
 * Test-Class.
 */
public class Main{
    public static void main(String[] args){
        A a = new A();
        B b = new B();
        System.out.println("Instance name: "+a.getName());
    }
}