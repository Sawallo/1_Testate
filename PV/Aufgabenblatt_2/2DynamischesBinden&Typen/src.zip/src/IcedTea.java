/**
 * Iced Tea is a cold drink.
 */
public class IcedTea extends Drink {

    public String temperature = "cold";
}