/**
 * Coffee is a hot drink.
 */
public class Coffee extends Drink {

    public String temperature = "hot";

    public String getTemperature() {
        return temperature;
    }
}